ICP project 2018
BlockEditor

David Hás - xhasda00
Ksenia Bolshakova - xbolsh00 



In this application you can create schemes from blocks and perform mathematical operations.

To add any block, click on buttons with operation name. Then you can move the blocks and connect them.

To input data, first create a block "Input" and connect it. After you enter your data, you can execute the calculation by clicking "Calculate all" or "Calculate next".

To connect two blocks, click on the icon "Connect" and then click on ports you wish to connect.

To move the scheme items, click on the icon "Select".

In the case you want to delete a block or a connection, first select the item and then press the "Del" button on your keyboard.

To cancel the selection of port for connection, press the "Esc" button on your keyboard.

To clear scheme, save or open, use the appropriate buttons.

All shortcuts can be found in the top context menu.
